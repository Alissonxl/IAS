import struct
import sys
from pathlib import Path

data = Path(sys.argv[1] if len(sys.argv) > 1 else r'C:\Program Files (x86)\MTA San Andreas 1.6\mods\deathmatch\client.dll').read_bytes()
u32 = lambda off: struct.unpack_from('<I', data, off)[0]
pe = u32(0x3c)
base = u32(pe + 24 + 28)
sections = []
for i in range(struct.unpack_from('<H', data, pe + 6)[0]):
    p = pe + 24 + struct.unpack_from('<H', data, pe + 20)[0] + 40 * i
    size, va, raw_size, raw = struct.unpack_from('<IIII', data, p + 8)
    sections.append((va, max(size, raw_size), raw, raw_size))
def va_at(off):
    for va, size, raw, raw_size in sections:
        if raw <= off < raw + raw_size:
            return base + va + off - raw
    raise ValueError(off)
def off_at(addr):
    for va, size, raw, raw_size in sections:
        if base + va <= addr < base + va + raw_size:
            return raw + addr - base - va
    raise ValueError(hex(addr))
def refs(addr):
    needle = struct.pack('<I', addr)
    p = data.find(needle)
    while p >= 0:
        yield p
        p = data.find(needle, p + 1)
for name in ([b'.?AVCPlayerPedSA@@', b'.?AVCEntitySA@@'] if len(sys.argv) > 1 else [b'.?AVCClientPlayer@@', b'.?AVCClientPed@@']):
    t = data.find(name)
    if t < 0: continue
    td = va_at(t - 8)
    print(name.decode(), 'type', hex(td))
    for ref in refs(td):
        if ref < 12 or u32(ref - 12) != 0: continue
        col = va_at(ref - 12)
        offset = u32(ref - 8)
        for r in refs(col):
            vtable = va_at(r + 4)
            entries = [u32(r + 4 + i * 4) for i in range(50)]
            if not all(base < e < base + 0x3b9000 for e in entries[:3]): continue
            print('vtable', hex(vtable), 'this_offset', hex(offset))
            for i, e in enumerate(entries):
                if not base < e < base + 0x3b9000: break
                print(i, hex(e), data[off_at(e):off_at(e)+14].hex(' '))
