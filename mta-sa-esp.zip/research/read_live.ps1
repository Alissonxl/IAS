$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class MtaReadOnly {
    [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
    [DllImport("kernel32.dll", SetLastError=true)] public static extern bool ReadProcessMemory(IntPtr process,IntPtr address,byte[] buffer,UIntPtr size,out UIntPtr read);
    [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr handle);
}
'@
$targetGame=Get-Process gta_sa
$modules=@{}; $targetGame.Modules | ForEach-Object { $modules[$_.ModuleName]=$_.BaseAddress.ToInt64() }
$gameBase=$modules['gta_sa.exe']; $clientBase=$modules['client.dll']
if (-not $gameBase -or -not $clientBase) { throw 'Modulos ainda nao carregados' }
$readHandle=[MtaReadOnly]::OpenProcess(0x1010,$false,[uint32]$targetGame.Id)
if ($readHandle -eq [IntPtr]::Zero) { throw 'OpenProcess somente leitura falhou' }
function Read-Data([long]$address,[int]$size) {
    $buffer=New-Object byte[] $size
    $done=[UIntPtr]::Zero
    if (-not [MtaReadOnly]::ReadProcessMemory($readHandle,[IntPtr]$address,$buffer,[UIntPtr]$size,[ref]$done) -or $done.ToUInt64() -ne $size) { throw ('Falha de leitura em {0:X8}' -f $address) }
    return ,$buffer
}
function Read-U32([long]$address) { [BitConverter]::ToUInt32((Read-Data $address 4),0) }
function Read-I32([long]$address) { [BitConverter]::ToInt32((Read-Data $address 4),0) }
try {
    $clientGame=Read-U32 ($clientBase+0x4b6960)
    $manager=Read-U32 ($clientGame+0x40)
    $first=Read-U32 ($manager+0x10); $last=Read-U32 ($manager+0x14)
    $total=($last-$first)/4
    if ($total -lt 0 -or $total -gt 4096) { throw 'Lista fora do limite' }
    $localPed=Read-U32 ($gameBase+0x76f5f0)
    $pluginOffset=Read-I32 ($gameBase+0x8978a4)
    'PID={0} jogadores={1} local={2:X8} skinPlugin={3:X}' -f $targetGame.Id,$total,$localPed,$pluginOffset
    for ($i=0;$i -lt [Math]::Min($total,8);$i++) {
        $player=Read-U32 ($first+$i*4)
        $vtable=Read-U32 $player
        if ($vtable -ne $clientBase+0x3c10f4) { throw 'Vtable diverge' }
        $wrapper=Read-U32 ($player+0x19c)
        if (-not $wrapper) { 'Jogador sem ped carregado'; continue }
        $vb=Read-U32 ($wrapper+4)
        $entity=$wrapper+4+(Read-I32 ($vb+4))
        $entity-=(Read-I32 ($entity-4))
        $vb=Read-U32 ($entity-0x14)
        $ped=Read-U32 ($entity+(Read-I32 ($vb+0x14))-0xc)
        $str=$player+0x6dc; $len=Read-U32 ($str+16); $cap=Read-U32 ($str+20)
        if ($len -gt 128 -or $cap -lt $len) { throw 'Nome fora do limite' }
        if ($cap -ge 16) { $str=Read-U32 $str }
        $name=[Text.Encoding]::UTF8.GetString((Read-Data $str $len))
        $clump=Read-U32 ($ped+0x18)
        $list=Read-U32 ($clump+8)
        $hier=Read-U32 ($list-0x40+$pluginOffset)
        $count=Read-U32 ($hier+4)
        if ($count -lt 1 -or $count -gt 128) { throw 'Hierarquia fora do limite' }
        $nodes=Read-U32 ($hier+16); $matrices=Read-U32 ($hier+8)
        $headPosition='ausente'
        for ($b=0;$b -lt $count;$b++) {
            if ((Read-U32 ($nodes+$b*16)) -eq 8) {
                $pos=Read-Data ($matrices+$b*64+48) 12
                $headPosition='{0:N3},{1:N3},{2:N3}' -f [BitConverter]::ToSingle($pos,0),[BitConverter]::ToSingle($pos,4),[BitConverter]::ToSingle($pos,8)
            }
        }
        'nome={0} ped={1:X8} local={2} ossos={3} cabeca={4}' -f $name,$ped,($ped -eq $localPed),$count,$headPosition
    }
} finally { [void][MtaReadOnly]::CloseHandle($readHandle) }
